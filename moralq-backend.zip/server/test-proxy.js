// test-proxy.js - Simple test script for the proxy server
// Run with: node test-proxy.js

const API_BASE_URL = process.env.TEST_URL || 'http://localhost:3000';

console.log('🧪 Testing MoralQ API Proxy Server');
console.log(`📡 Target: ${API_BASE_URL}\n`);

// Test 1: Health Check
async function testHealth() {
    console.log('TEST 1: Health Check');
    console.log('──────────────────────────────────');

    try {
        const response = await fetch(`${API_BASE_URL}/health`);
        const data = await response.json();

        if (response.ok && data.status === 'ok') {
            console.log('✅ PASSED');
            console.log(`   Status: ${data.status}`);
            console.log(`   Keys Available: ${data.keysAvailable}`);
            console.log(`   Timestamp: ${data.timestamp}\n`);
            return true;
        } else {
            console.log('❌ FAILED');
            console.log(`   Response: ${JSON.stringify(data)}\n`);
            return false;
        }
    } catch (error) {
        console.log('❌ FAILED');
        console.log(`   Error: ${error.message}\n`);
        return false;
    }
}

// Test 2: Stats Endpoint
async function testStats() {
    console.log('TEST 2: API Stats');
    console.log('──────────────────────────────────');

    try {
        const response = await fetch(`${API_BASE_URL}/api/stats`);
        const data = await response.json();

        if (response.ok && data.success) {
            console.log('✅ PASSED');
            console.log(`   Total Keys: ${data.stats.totalKeys}`);
            console.log(`   Current Key: #${data.stats.currentKey}`);
            console.log(`   Available Keys: ${data.stats.availableKeys}`);
            console.log(`   Blocked Keys: ${data.stats.blockedKeys}`);
            console.log(`   Total Requests: ${data.stats.totalRequests}`);
            console.log(`   Max Capacity: ${data.stats.maxCapacity}`);
            console.log(`   Usage: ${data.stats.usagePercentage}\n`);
            return true;
        } else {
            console.log('❌ FAILED');
            console.log(`   Response: ${JSON.stringify(data)}\n`);
            return false;
        }
    } catch (error) {
        console.log('❌ FAILED');
        console.log(`   Error: ${error.message}\n`);
        return false;
    }
}

// Test 3: Chat Endpoint
async function testChat() {
    console.log('TEST 3: Chat API');
    console.log('──────────────────────────────────');

    try {
        const response = await fetch(`${API_BASE_URL}/api/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                prompt: 'Halo! Jelaskan singkat apa itu moral intelligence dalam 1 kalimat.',
                chatHistory: []
            })
        });

        const data = await response.json();

        if (response.ok && data.success) {
            console.log('✅ PASSED');
            console.log(`   Response: ${data.response.substring(0, 100)}...`);
            console.log(`   Key Used: #${data.stats.keyIndex}`);
            console.log(`   Total Requests: ${data.stats.totalRequests}`);
            console.log(`   Available Keys: ${data.stats.availableKeys}\n`);
            return true;
        } else {
            console.log('❌ FAILED');
            console.log(`   Error: ${data.error || 'Unknown error'}`);
            console.log(`   Full Response: ${JSON.stringify(data)}\n`);
            return false;
        }
    } catch (error) {
        console.log('❌ FAILED');
        console.log(`   Error: ${error.message}\n`);
        return false;
    }
}

// Test 4: Rate Limiting (rapid requests)
async function testRateLimit() {
    console.log('TEST 4: Rate Limiting');
    console.log('──────────────────────────────────');
    console.log('Sending 3 rapid requests...\n');

    const promises = [];
    for (let i = 0; i < 3; i++) {
        promises.push(
            fetch(`${API_BASE_URL}/api/chat`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    prompt: `Test ${i + 1}`,
                    chatHistory: []
                })
            })
        );
    }

    try {
        const responses = await Promise.all(promises);
        const results = await Promise.all(responses.map(r => r.json()));

        let successCount = 0;
        results.forEach((result, i) => {
            if (result.success) {
                console.log(`   Request ${i + 1}: ✅ Success`);
                successCount++;
            } else {
                console.log(`   Request ${i + 1}: ⚠️ ${result.error || 'Failed'}`);
            }
        });

        console.log(`\n   ${successCount}/3 requests succeeded`);
        console.log('   Note: Some may fail due to rate limiting (expected)\n');
        return true;
    } catch (error) {
        console.log('❌ FAILED');
        console.log(`   Error: ${error.message}\n`);
        return false;
    }
}

// Run all tests
async function runAllTests() {
    const startTime = Date.now();

    console.log('═══════════════════════════════════════════════\n');

    const results = {
        health: await testHealth(),
        stats: await testStats(),
        chat: await testChat(),
        rateLimit: await testRateLimit()
    };

    const endTime = Date.now();
    const duration = ((endTime - startTime) / 1000).toFixed(2);

    console.log('═══════════════════════════════════════════════');
    console.log('📊 TEST SUMMARY');
    console.log('═══════════════════════════════════════════════');
    console.log(`Health Check:    ${results.health ? '✅ PASSED' : '❌ FAILED'}`);
    console.log(`API Stats:       ${results.stats ? '✅ PASSED' : '❌ FAILED'}`);
    console.log(`Chat API:        ${results.chat ? '✅ PASSED' : '❌ FAILED'}`);
    console.log(`Rate Limiting:   ${results.rateLimit ? '✅ PASSED' : '❌ FAILED'}`);
    console.log('═══════════════════════════════════════════════');

    const passedTests = Object.values(results).filter(r => r).length;
    const totalTests = Object.keys(results).length;

    console.log(`\n🎯 Result: ${passedTests}/${totalTests} tests passed`);
    console.log(`⏱️  Duration: ${duration}s\n`);

    if (passedTests === totalTests) {
        console.log('🎉 All tests passed! Server is working correctly.\n');
        process.exit(0);
    } else {
        console.log('⚠️  Some tests failed. Check the logs above.\n');
        process.exit(1);
    }
}

// Run tests
runAllTests().catch(error => {
    console.error('💥 Test runner error:', error);
    process.exit(1);
});
