// proxy-server.js - Secure Gemini API Proxy with Rotation
// This server keeps API keys secure on the backend

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : '*',
    credentials: true
}));
app.use(express.json());

// Rate limiting per IP
const limiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 30, // max 30 requests per minute per IP
    message: { error: 'Too many requests, please try again later.' }
});
app.use('/api/', limiter);

// ========================================
// 🔑 API KEY ROTATION SYSTEM (SERVER-SIDE)
// ========================================

// Load API keys from environment variables
const API_KEYS = process.env.GEMINI_API_KEYS
    ? process.env.GEMINI_API_KEYS.split(',').map(key => key.trim())
    : [];

if (API_KEYS.length === 0) {
    console.error('❌ ERROR: No API keys found in .env file!');
    console.error('   Please add GEMINI_API_KEYS="key1,key2,key3" to your .env file');
    process.exit(1);
}

console.log(`✅ Loaded ${API_KEYS.length} API keys from environment`);

// API Key Rotation Manager
class ServerAPIKeyManager {
    constructor() {
        this.currentKeyIndex = 0;
        this.keyStats = {};
        this.initializeKeyStats();

        // Reset daily stats at midnight
        this.scheduleDailyReset();
    }

    initializeKeyStats() {
        API_KEYS.forEach((_, index) => {
            this.keyStats[index] = {
                dailyCount: 0,
                lastRequestTime: 0,
                failCount: 0,
                isBlocked: false,
                lastReset: new Date().toDateString()
            };
        });
    }

    scheduleDailyReset() {
        const now = new Date();
        const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
        const msUntilMidnight = tomorrow - now;

        setTimeout(() => {
            console.log('🔄 Midnight reset - clearing all daily stats');
            this.initializeKeyStats();
            this.scheduleDailyReset(); // Schedule next reset
        }, msUntilMidnight);
    }

    getCurrentKey() {
        return API_KEYS[this.currentKeyIndex];
    }

    getCurrentKeyIndex() {
        return this.currentKeyIndex;
    }

    canUseCurrentKey() {
        const stats = this.keyStats[this.currentKeyIndex];

        if (!stats || stats.isBlocked) {
            return false;
        }

        // Check daily limit (Free tier: 1500 requests/day)
        if (stats.dailyCount >= 1500) {
            console.warn(`⚠️ Key #${this.currentKeyIndex} reached daily limit`);
            return false;
        }

        // Check rate limiting (min 4 seconds between requests)
        const now = Date.now();
        const timeSinceLastRequest = now - stats.lastRequestTime;
        if (timeSinceLastRequest < 4000) {
            console.log(`⏳ Key #${this.currentKeyIndex} in cooldown`);
            return false;
        }

        return true;
    }

    rotateToNextKey() {
        const startIndex = this.currentKeyIndex;
        let attempts = 0;

        while (attempts < API_KEYS.length) {
            this.currentKeyIndex = (this.currentKeyIndex + 1) % API_KEYS.length;
            attempts++;

            if (this.canUseCurrentKey()) {
                console.log(`✅ Rotated to API Key #${this.currentKeyIndex}`);
                return true;
            }
        }

        console.error('❌ All API keys are blocked or at limit!');
        return false;
    }

    markRequest() {
        const stats = this.keyStats[this.currentKeyIndex];
        stats.dailyCount++;
        stats.lastRequestTime = Date.now();

        console.log(`📊 Key #${this.currentKeyIndex}: ${stats.dailyCount}/1500 requests today`);
    }

    markFailure(errorMessage = '') {
        const stats = this.keyStats[this.currentKeyIndex];
        stats.failCount++;

        // Block key if quota/429 error
        if (errorMessage.includes('quota') || errorMessage.includes('429') || errorMessage.includes('leaked')) {
            stats.isBlocked = true;
            console.warn(`🚫 Key #${this.currentKeyIndex} blocked: ${errorMessage}`);
        }
    }

    getOverallStats() {
        let totalRequests = 0;
        let availableKeys = 0;
        let blockedKeys = 0;

        Object.values(this.keyStats).forEach(stats => {
            totalRequests += stats.dailyCount;
            if (stats.isBlocked) {
                blockedKeys++;
            } else if (stats.dailyCount < 1500) {
                availableKeys++;
            }
        });

        return {
            totalKeys: API_KEYS.length,
            currentKey: this.currentKeyIndex,
            totalRequests,
            availableKeys,
            blockedKeys,
            maxDailyCapacity: API_KEYS.length * 1500
        };
    }
}

const keyManager = new ServerAPIKeyManager();

// ========================================
// 🚀 API ENDPOINTS
// ========================================

// Health check
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        keysAvailable: keyManager.getOverallStats().availableKeys
    });
});

// Get API stats (for monitoring)
app.get('/api/stats', (req, res) => {
    const stats = keyManager.getOverallStats();
    res.json({
        success: true,
        stats: {
            totalKeys: stats.totalKeys,
            currentKey: stats.currentKey,
            availableKeys: stats.availableKeys,
            blockedKeys: stats.blockedKeys,
            totalRequests: stats.totalRequests,
            maxCapacity: stats.maxDailyCapacity,
            usagePercentage: ((stats.totalRequests / stats.maxDailyCapacity) * 100).toFixed(2) + '%'
        }
    });
});

// Proxy endpoint for Gemini API
app.post('/api/chat', async (req, res) => {
    try {
        const { prompt, chatHistory = [] } = req.body;

        if (!prompt) {
            return res.status(400).json({ error: 'Prompt is required' });
        }

        // Check if we can use current key, rotate if needed
        if (!keyManager.canUseCurrentKey()) {
            const rotated = keyManager.rotateToNextKey();
            if (!rotated) {
                return res.status(429).json({
                    error: 'All API keys have reached their limit. Please try again later.',
                    stats: keyManager.getOverallStats()
                });
            }
        }

        // Mark request
        keyManager.markRequest();

        // Get current API key
        const apiKey = keyManager.getCurrentKey();
        const keyIndex = keyManager.getCurrentKeyIndex();

        console.log(`🔑 Using Key #${keyIndex} for request`);

        // Call Gemini API
        const { GoogleGenerativeAI } = require('@google/generative-ai');
        const genAI = new GoogleGenerativeAI(apiKey);

        // Try gemini-2.0-flash first, fallback to others
        let model;
        try {
            model = genAI.getGenerativeModel({ model: 'gemini-2.0-flash' });
        } catch (e) {
            console.warn('gemini-2.0-flash not available, trying gemini-1.5-flash');
            model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
        }

        const generationConfig = {
            temperature: 0.7,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 1024,
        };

        const safetySettings = [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_ONLY_HIGH" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" },
        ];

        const systemPrompt = `Anda adalah asisten AI eksklusif untuk aplikasi "MoralQ - Moral Intelligence". Ini adalah aplikasi pembelajaran dan pengembangan moral intelligence khusus untuk pendidik dan guru.

IDENTITAS ANDA:
- Nama: MoralQ AI Assistant
- Bagian dari: Aplikasi MoralQ - Moral Intelligence
- Tujuan: Membantu pendidik memahami dan mengajarkan moral intelligence

TENTANG APLIKASI MORALQ:
- Aplikasi PWA (Progressive Web App) untuk pembelajaran moral intelligence
- Target pengguna: Guru dan pendidik
- Fokus: 7 Aspek Moral Intelligence
  1. Empati - Kemampuan memahami dan merasakan perasaan orang lain
  2. Hati Nurani - Kemampuan membedakan benar dan salah
  3. Pengendalian Diri - Kemampuan mengendalikan emosi dan perilaku
  4. Hormat - Sikap menghargai diri sendiri dan orang lain
  5. Kebaikan Hati - Sikap peduli dan membantu orang lain
  6. Toleransi - Kemampuan menerima perbedaan
  7. Keadilan - Sikap adil dalam bertindak

FITUR APLIKASI:
- Chat AI (tempat percakapan ini)
- Asesmen Moral Intelligence
- Artikel & Modul Pembelajaran
- Rencana Pembelajaran (RPP)
- Forum Komunitas Pendidik
- Tracking Progress

CARA MENJAWAB:
1. Jika ditanya "aplikasi apa ini?", "apa fungsi aplikasi ini?", dll:
   → Jelaskan bahwa ini adalah MoralQ, aplikasi pembelajaran moral intelligence untuk pendidik

2. Jika ditanya tentang moral intelligence:
   → Berikan penjelasan praktis dengan contoh nyata untuk konteks pendidikan

3. Jika ditanya cara pakai fitur:
   → Arahkan ke menu yang sesuai (Asesmen, Artikel, RPP, Forum)

4. Selalu fokus pada:
   - Konteks pendidikan dan pengajaran
   - 7 aspek moral intelligence
   - Praktis dan actionable
   - Mendorong refleksi dan pengembangan

GAYA BAHASA:
- Ramah, profesional, mendukung
- Bahasa Indonesia natural
- Hindari jargon teknis berlebihan
- Fokus pada solusi praktis untuk guru`;

        const history = [
            { role: "user", parts: [{ text: systemPrompt }] },
            { role: "model", parts: [{ text: "Halo! Saya MoralQ AI Assistant, bagian dari aplikasi MoralQ - Moral Intelligence. Saya di sini untuk membantu Anda sebagai pendidik dalam memahami dan mengajarkan 7 aspek moral intelligence kepada siswa. Ada yang ingin Anda diskusikan atau tanyakan tentang moral intelligence atau fitur aplikasi ini?" }] },
            ...chatHistory.slice(-8)
        ];

        const chat = model.startChat({
            generationConfig,
            safetySettings,
            history: history
        });

        const result = await chat.sendMessage(prompt);
        const response = await result.response;
        const text = response.text();

        // Log stats
        const stats = keyManager.getOverallStats();
        console.log(`📊 Stats: ${stats.totalRequests}/${stats.maxDailyCapacity} | Available: ${stats.availableKeys}/${stats.totalKeys}`);

        res.json({
            success: true,
            response: text.trim(),
            stats: {
                keyIndex: keyIndex,
                totalRequests: stats.totalRequests,
                availableKeys: stats.availableKeys
            }
        });

    } catch (error) {
        console.error('❌ Error in /api/chat:', error);

        // Mark failure
        const errorMsg = error.message || String(error);
        keyManager.markFailure(errorMsg);

        // If quota error, try to rotate and suggest retry
        if (errorMsg.includes('quota') || errorMsg.includes('429') || errorMsg.includes('leaked')) {
            const rotated = keyManager.rotateToNextKey();

            if (rotated) {
                return res.status(429).json({
                    error: 'API key quota exceeded, rotated to next key. Please retry.',
                    shouldRetry: true,
                    stats: keyManager.getOverallStats()
                });
            } else {
                return res.status(429).json({
                    error: 'All API keys have reached their limit. Please try again later.',
                    shouldRetry: false,
                    stats: keyManager.getOverallStats()
                });
            }
        }

        res.status(500).json({
            error: 'Internal server error',
            message: process.env.NODE_ENV === 'development' ? errorMsg : 'An error occurred'
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`\n${'='.repeat(50)}`);
    console.log(`🚀 MoralQ Secure API Proxy Server`);
    console.log(`${'='.repeat(50)}`);
    console.log(`✅ Server running on port ${PORT}`);
    console.log(`📊 Total API Keys: ${API_KEYS.length}`);
    console.log(`🔒 API keys are secure (not exposed to client)`);
    console.log(`🌐 CORS: ${process.env.ALLOWED_ORIGINS || 'All origins (*)' }`);
    console.log(`${'='.repeat(50)}\n`);
});
