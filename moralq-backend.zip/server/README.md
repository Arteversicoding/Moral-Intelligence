# 🔐 MoralQ Secure API Proxy Server

Backend server yang menyimpan Gemini API keys dengan **100% aman** dan tidak ter-expose ke client.

## 📁 File Structure

```
server/
├── proxy-server.js      # Main server file
├── package.json         # Dependencies
├── .env                 # API keys (NEVER commit!)
└── README.md           # This file
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
npm install
```

### 2. Create `.env` File

```bash
cp ../.env.example .env
```

Edit `.env`:
```env
NODE_ENV=production
PORT=3000
ALLOWED_ORIGINS=https://moralq.com
GEMINI_API_KEYS="key1,key2,key3,key4,key5"
```

### 3. Run Server

**Development:**
```bash
npm run dev
```

**Production:**
```bash
npm start
```

## 📡 API Endpoints

### `GET /health`
Health check endpoint.

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2025-01-20T10:30:00.000Z",
  "keysAvailable": 5
}
```

### `GET /api/stats`
Get API usage statistics.

**Response:**
```json
{
  "success": true,
  "stats": {
    "totalKeys": 5,
    "currentKey": 0,
    "availableKeys": 5,
    "blockedKeys": 0,
    "totalRequests": 123,
    "maxCapacity": 7500,
    "usagePercentage": "1.64%"
  }
}
```

### `POST /api/chat`
Main chat endpoint (proxies to Gemini API).

**Request:**
```json
{
  "prompt": "Apa itu moral intelligence?",
  "chatHistory": [
    {
      "role": "user",
      "parts": [{"text": "Halo"}]
    },
    {
      "role": "model",
      "parts": [{"text": "Halo! Ada yang bisa saya bantu?"}]
    }
  ]
}
```

**Response (Success):**
```json
{
  "success": true,
  "response": "Moral intelligence adalah...",
  "stats": {
    "keyIndex": 0,
    "totalRequests": 124,
    "availableKeys": 5
  }
}
```

**Response (Error - Quota Exceeded):**
```json
{
  "error": "API key quota exceeded, rotated to next key. Please retry.",
  "shouldRetry": true,
  "stats": {...}
}
```

## 🔑 API Key Rotation

Server automatically rotates between multiple API keys to avoid quota limits:

- **Daily Limit:** 1500 requests per key
- **Rate Limit:** Minimum 4 seconds between requests per key
- **Auto Rotation:** When a key hits quota, automatically switches to next available key
- **Auto Reset:** Daily counters reset at midnight UTC

## 🛡️ Security Features

- ✅ API keys stored in `.env` (never exposed to client)
- ✅ CORS protection (only allowed origins)
- ✅ Rate limiting per IP (30 requests/minute)
- ✅ Automatic key blocking on leaked/quota errors
- ✅ No API keys in logs or responses

## 📊 Monitoring

### Check Server Health

```bash
curl https://your-server.com/health
```

### Check API Stats

```bash
curl https://your-server.com/api/stats
```

### View Logs (PM2)

```bash
pm2 logs moralq-api
```

## 🚀 Deployment

### Railway.app (Recommended)

1. Push code to GitHub
2. Connect Railway to your repo
3. Set Root Directory: `Moral-Intelligence/server`
4. Add Environment Variables (see `.env.example`)
5. Deploy!

### Heroku

```bash
heroku create moralq-api
heroku config:set NODE_ENV=production
heroku config:set GEMINI_API_KEYS="key1,key2,key3"
git subtree push --prefix Moral-Intelligence/server heroku main
```

### VPS (DigitalOcean, AWS, etc.)

```bash
# Install Node.js and PM2
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs
sudo npm install -g pm2

# Clone and setup
git clone https://github.com/yourusername/moralq.git
cd moralq/Moral-Intelligence/server
npm install

# Create .env file
nano .env
# (paste your API keys)

# Start with PM2
pm2 start proxy-server.js --name moralq-api
pm2 save
pm2 startup
```

Setup Nginx reverse proxy:
```nginx
server {
    listen 80;
    server_name api.moralq.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🔧 Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `NODE_ENV` | No | `development` | Environment mode |
| `PORT` | No | `3000` | Server port |
| `ALLOWED_ORIGINS` | No | `*` | CORS allowed origins (comma-separated) |
| `GEMINI_API_KEYS` | **Yes** | - | Gemini API keys (comma-separated) |

## 🐛 Troubleshooting

### Error: "No API keys found in .env file"

**Fix:**
```bash
# Check .env exists
ls -la .env

# Check format
cat .env

# Should be:
GEMINI_API_KEYS="key1,key2,key3"
```

### Error: "All API keys have reached their limit"

**Fix:**
- Add more API keys to `.env`
- Wait until midnight UTC for daily reset
- Upgrade to paid Gemini API plan

### Error: "CORS error"

**Fix:**
```env
# In .env, add your domain
ALLOWED_ORIGINS=https://moralq.com,https://www.moralq.com
```

## 📝 License

MIT

## 🤝 Contributing

1. Fork the repo
2. Create feature branch
3. Commit changes
4. Push to branch
5. Open Pull Request

## 📞 Support

- GitHub Issues: [Report a bug](https://github.com/yourusername/moralq/issues)
- Email: support@moralq.com
